package com.example.create_mission

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ExecuteQuest : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_execute_quest)
    }
}